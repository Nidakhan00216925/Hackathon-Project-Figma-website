import Image from "next/image";
import pic1 from "@/images/product-cover-5 (21).png"
import pic2 from "@/images/product-cover-5 (22).png"
import pic3 from "@/images/product-cover-5 (23).png"
import pic4 from "@/images/product-cover-5 (24).png"
import pic5 from "@/images/product-cover-5 (25).png"

export default function Bestseller(){
    return(
        <div >

        </div>
    )
}
